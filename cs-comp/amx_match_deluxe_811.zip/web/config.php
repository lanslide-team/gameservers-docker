<?php
/*************************************************************
*
*	Configuration file for AMXMD Template
*
*************************************************************/


// Set the hostname for the database
$mysql_host = "localhost";

// Set the username for the database
$mysql_username = "root";

// Set the password for the database
$mysql_password = "";

// Set the database name
$mysql_database = "amx_match_deluxe";

// Set the title of the stats pages ( text is also used in place of a banner )
$server_name = "AMX Match Deluxe Match Stats";	



?>