<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<?php

	include_once("config.php");
	include_once("misc_functions.php");
	include_once("mysql_connect.php");
	
?>


<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
	<meta name="description" content="description"/>
	<meta name="keywords" content="keywords"/> 
	<meta name="author" content="Infra"/> 
	<link rel="stylesheet" type="text/css" href="default.css" media="screen"/>
<?php

if ( isset($_GET["match"]) && $_GET["match"] > 0 )
{
	$sql = "SELECT * FROM `amx_match_main` WHERE `match_id` = " . $_GET["match"];
	$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
	{
		$half_id = $match_data['half1_id'];
		
		// Get team_id's from half_id
		$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
		$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		$half_data = mysql_fetch_array($half_query);				
		
		$team1_id = $half_data['team1_id'];
		$team2_id = $half_data['team2_id'];
		
		// Get Team names from team_id's
		// Get team1_id name
		$team1_name = get_team_name($team1_id, $link);
		$team1_name = htmlspecialchars($team1_name);
		
		// Get team2_id name
		$team2_name = get_team_name($team2_id, $link);
		$team2_name = htmlspecialchars($team2_name);	

?>
	<title><?=$server_name?> - Match <?=$team1_name?> vs. <?=$team2_name?></title>
		
<?php

	}
	else
	{
	

?>

	<title><?=$server_name?> - Match #<?=$_GET["match"]?></title>

<?php
	}
}
else
{
	
	
?>

	<title><?=$server_name?> - Matches</title>
	
<?php

}

?>

</head>

<!-- default margin = default layout -->
<body style="margin: 0 12%;">

<div class="container">

	<div class="header">
		<a href="index.php"><span><?=$server_name?></span></a>
	</div>
	
	<div class="nav">
		<a href="index.php">Matches</a>
		<a href="player.php">Players</a>
		<a href="team.php">Teams</a>
		<a href="map.php">Maps</a>
		<div class="clearer"></div>
	</div>

	<div class="stripes"></div>

	<div class="main">

<?php

if ( isset($_GET["match"]) && $_GET["match"] > 0 )
{
	$sql = "SELECT * FROM `amx_match_main` WHERE `match_id` = " . $_GET["match"];
	$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
	{
		// Pull the neccesary stuff from the match row
		$match_id = $match_data['match_id'];
		$half_id = $match_data['half1_id'];
	
		// Get team_id's from half_id
		$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
		$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		$half_data = mysql_fetch_array($half_query);
		
		$team1_id = $half_data['team1_id'];
		$team2_id = $half_data['team2_id'];
		
		// Get Team names from team_id's
		// Get team1_id name
		$team1_name = get_team_name($team1_id, $link);
		$team1_name = htmlspecialchars($team1_name);
		
		// Get team2_id name
		$team2_name = get_team_name($team2_id, $link);
		$team2_name = htmlspecialchars($team2_name);

		$team1_score = 0;
		$team2_score = 0;

		for($i = 1; $i < 9; $i++)
		{	
			// Pull the neccesary stuff from the match row
			$half_id = $match_data["half" . $i . "_id"];
			
			if( $half_id != -1 )
			{
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);
				
				if( $i % 2 == 0 )
				{
					$team2_score += $half_data['team1_score'];
					$team1_score += $half_data['team2_score'];
				}
				else
				{
					$team1_score += $half_data['team1_score'];
					$team2_score += $half_data['team2_score'];
				}
			}
		}
				
							
?>

		<div class="listing">
			Match Listing - Match <?=$team1_name?> vs. <?=$team2_name?>
		</div>

		<br />
		<div class="content-title">Scores:</div>
		<table class="content" width="30%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td style="padding-left: 3px; width: 75%;" align="left">Team</td>
				<td style="width: 25%;" align="left">Score</td>
			</tr>
			
			<tr class="table-shade2">
				<td style="padding-left: 3px;" align="left"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a></td>
				<td align="left"><?=$team1_score?></td>
			</tr>

			<tr class="table-shade3">
				<td style="padding-left: 3px;" align="left"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a></td>
				<td align="left"><?=$team2_score?></td>
			</tr>
		</table>
		
		
		<br />
		<br />
		<div class="content-title">Halves:</div>
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 10%;">Half</td>
				<td align="left" style="width: 25%;">Terrorists</td>
				<td align="center" style="width: 20%;">T score</td>
				<td align="left"style="width: 35%;">Counter-terrorists</td>
				<td align="center" style="width: 10%;">CT score</td>
			</tr>

<?php

		$shade_changer = -1;
		$shade = 3;

		for($i = 1; $i < 9; $i++)
		{
			// Pull the neccesary stuff from the match row
			$half_id = $match_data["half" . $i . "_id"];
			
			if( $half_id != -1 )
			{
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);
				
				$team1_id = $half_data['team1_id'];
				$team1_score = $half_data['team1_score'];
				$team2_id = $half_data['team2_id'];
				$team2_score = $half_data['team2_score'];
				
				// Get Team names from team_id's
				// Get team1_id name
				$team1_name = get_team_name($team1_id, $link);
				$team1_name = htmlspecialchars($team1_name);
				
				// Get team2_id name
				$team2_name = get_team_name($team2_id, $link);
				$team2_name = htmlspecialchars($team2_name);
				
				// Change shade from 2 to 3 -or- 3 to 2
				$shade += $shade_changer;
				$shade_changer = -$shade_changer;
?>			

			<tr class="table-shade<?=$shade?>">
				<td align="center"><a href="#half<?=$i?>"><?=$i?></a></td>
				<td align="left"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a></td>
				<td align="center"><?=$team1_score?></td>
				<td align="left"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a></td>
				<td align="center"><?=$team2_score?></td>
			</tr>

<?php
				
			}
		}
		
?>
			
		</table>
		
		
<?php

		$map1_id = $match_data['map1_id'];
		$map2_id = $match_data['map2_id'];

		// Get map name from map1_id
		$map1_name = get_map_name($map1_id, $link);
		
?>
		
		<br />
		<br />
		<table style="margin-left: 2%" width="97%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td valign="top">
		
					<div class="content-title2">Map(s):</div>
					<table class="content2" width="96%" cellpadding="0" cellspacing="0" border="0">
						<tr class="table-shade1">
							<td align="center">Map</td>
						</tr>
						
						<tr class="table-shade2">
							<td align="center"><a href="map.php?map=<?=$map1_id?>"><?=$map1_name?></a></td>
						</tr>
<?php

		if( $map2_id != -1 )
		{
			// Get map name from map2_id
			$map2_name = get_map_name($map2_id, $link);
			
?>
			
						<tr class="table-shade3">
							<td align="center"><a href="map.php?map=<?=$map2_id?>"><?=$map2_name?></a></td>
						</tr>
<?php

		}
		
?>

									
					</table>
				
				</td>
			
				<td valign="top">
			
					<div class="content-title">Players:</div>	
					<table class="content" width="97%" cellpadding="0" cellspacing="0" border="0">
						<tr class="table-shade1">
							<td align="center">#</td>
							<td align="center">SteamID</td>
							<td align="left">Name</td>
							<td align="left">Team</td>
						</tr>

<?php

		for($i = 1; $i < 9; $i++)
		{
			// Pull the neccesary stuff from the match row
			$half_id = $match_data["half" . $i . "_id"];
			
			if( $half_id != -1 )
			{
				// Get player's from half_id
				$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `half_id`=" . $half_id . " GROUP BY `player_id`";
				$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				
				while ( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
				{	
					$player_id = $player_stats_data['player_id'];
					$team_id = $player_stats_data['team_id'];

					// Get player steamid
					$player_steamid = get_player_steamid($player_id, $link);
					$player_steamid = htmlspecialchars($player_steamid);				

					// Get player name
					$player_name = get_player_name($player_id, $link);
					$player_name = htmlspecialchars($player_name);
		
					// Get team_id name
					$team_name = get_team_name($team_id, $link);
					$team_name = htmlspecialchars( $team_name );
					
					$player_authid[$player_id] = $player_steamid;
					$player_names[$player_id] = $player_name;
					$player_team[$player_id] = $team_name;
					$player_teamid[$player_id] = $team_id;
					
				}
			}
		}
				
		$j = 0;
		
		$shade_changer = -1;
		$shade = 3;
		
		foreach ($player_authid as $i => $value)
		{		
				$j++;
			
				// Change shade from 2 to 3 -or- 3 to 2
				$shade += $shade_changer;
				$shade_changer = -$shade_changer;		
?>
					
						<tr class="table-shade<?=$shade?>">
							<td align="center"><?=$j?></td>
							<td align="center"><a href="player.php?player=<?=$i?>"><?=$player_authid[$i]?></a></td>
							<td align="left"><?=$player_names[$i]?></td>
							<td align="left"><a href="team.php?team=<?=$player_teamid[$i]?>"><?=$player_team[$i]?></a></td>
						</tr>
						
<?php

		}
		
?>
					</table>
					
				</td>
			</tr>
		</table>

<?php

		for($i = 1; $i < 9; $i++)
		{
			// Pull the neccesary stuff from the match row
			$half_id = $match_data["half" . $i . "_id"];
			
			if( $half_id != -1 )
			{
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);				
				
				$team1_id = $half_data['team1_id'];
				$team1_score = $half_data['team1_score'];
				$team2_id = $half_data['team2_id'];
				$team2_score = $half_data['team2_score'];
				
				// Get Team names from team_id's
				// Get team1_id name
				$team1_name = get_team_name($team1_id, $link);
				$team1_name = htmlspecialchars($team1_name);
				
				// Get team2_id name
				$team2_name = get_team_name($team2_id, $link);
				$team2_name = htmlspecialchars($team2_name);

?>

		<br />
		<br />
		<div class="content-title"><a id="half<?=$i?>">Half <?=$i?>:</a></div>
		<div style="margin-left: 4%">
			<div class="content-title">Scores:</div>
			<table class="content" width="30%" cellpadding="0" cellspacing="0" border="0">
				<tr class="table-shade1">
					<td style="padding-left: 3px; width: 75%;" align="left">Team</td>
					<td style="width: 25%;" align="left">Score</td>
				</tr>
				
				<tr class="table-shade2">
					<td style="padding-left: 3px;" align="left"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a></td>
					<td align="left"><?=$team1_score?></td>
				</tr>
	
				<tr class="table-shade3">
					<td style="padding-left: 3px;" align="left"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a></td>
					<td align="left"><?=$team2_score?></td>
				</tr>
			</table>

			<br />
			<table style="margin-left: 1.1%" width="97%" cellpadding="0" cellspacing="0" border="0">
				<tr>				
					<td valign="top">
				
						<div class="content-title"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a>:</div>	
						<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
							<tr class="table-shade1">
								<td align="left" style="padding-left: 3px;">SteamID</td>
								<td align="left">Name</td>
								<td align="center">Frags</td>
								<td align="center">Deaths</td>
							</tr>

<?php

				$shade_changer = -1;
				$shade = 3;

				// Get player's from half_id
				$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `half_id`=" . $half_id . " AND `team_id`=". $team1_id;
				$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				
				while ( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
				{	
					$player_id = $player_stats_data['player_id'];
					$player_frags = $player_stats_data['player_frags'];
					$player_deaths = $player_stats_data['player_deaths'];

					// Get player_id steamid
					$player_steamid = get_player_steamid($player_id, $link);
					$player_steamid = htmlspecialchars($player_steamid);
					
					// Get player name
					$player_name = get_player_name($player_id, $link);
					$player_name = htmlspecialchars($player_name);
					
					// Change shade from 2 to 3 -or- 3 to 2
					$shade += $shade_changer;
					$shade_changer = -$shade_changer;
							

?>							
							<tr class="table-shade<?=$shade?>">
								<td align="left" style="padding-left: 3px;"><a href="player.php?player=<?=$player_id?>"><?=$player_steamid?></a></td>
								<td align="left"><?=$player_name?></td>
								<td align="center"><?=$player_frags?></td>
								<td align="center"><?=$player_deaths?></td>
							</tr>
<?php

				}
				
?>
						</table>
						
					</td>
					
					<td valign="top">
				
						<div class="content-title"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a>:</div>	
						<table class="content" width="97%" cellpadding="0" cellspacing="0" border="0">
							<tr class="table-shade1">
								<td align="left" style="padding-left: 3px;">SteamID</td>
								<td align="left">Name</td>
								<td align="center">Frags</td>
								<td align="center">Deaths</td>
							</tr>

<?php

				$shade_changer = -1;
				$shade = 3;

				// Get player's from half_id
				$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `half_id`=" . $half_id . " AND `team_id`=". $team2_id;
				$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				
				while ( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
				{	
					$player_id = $player_stats_data['player_id'];
					$player_frags = $player_stats_data['player_frags'];
					$player_deaths = $player_stats_data['player_deaths'];

					// Get player_id steamid
					$player_steamid = get_player_steamid($player_id, $link);
					$player_steamid = htmlspecialchars($player_steamid);
					
					// Get player name
					$player_name = get_player_name($player_id, $link);
					$player_name = htmlspecialchars($player_name);
					
					// Change shade from 2 to 3 -or- 3 to 2
					$shade += $shade_changer;
					$shade_changer = -$shade_changer;
							

?>							
							<tr class="table-shade<?=$shade?>">
								<td align="left" style="padding-left: 3px;"><a href="player.php?player=<?=$player_id?>"><?=$player_steamid?></a></td>
								<td align="left"><?=$player_name?></td>
								<td align="center"><?=$player_frags?></td>
								<td align="center"><?=$player_deaths?></td>
							</tr>
<?php

				}
				
?>
						</table>
						
					</td>
				</tr>
			</table>
		</div>	
<?php

			}
		}
		
?>
		
		
		<br />
		<br />

<?php			

	}
	else
	{
		
?>
		<br />
		<br />
		<div class="content-title">Error: Invalid match number: <?=$_GET["match"]?></div>
		<br />
		<br />
		
<?php
	}
	
}	
else
{
	
?>

		<div class="listing">
			Match Listing
		</div>	

		<br />
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 5%;">#</td>
				<td align="left" style="width: 20%;">Team 1</td>
				<td align="left" style="width: 15%;">Score</td>
				<td align="left" style="width: 25%;">Team 2</td>
				<td align="left" style="width: 10%;">Score</td>
				<td align="left" style="width: 15%;">First Map</td>
				<td align="left" style="width: 10%;">Second Map</td>
			</tr>
<?php

	$shade_changer = -1;
	$shade = 3;
	
	$i = 0;
	$j = 0;
	
	$sql = "SELECT * FROM `amx_match_main` ORDER BY `match_id` ASC;";
	$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	while($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
	{
		$j++;
		
		// Pull the neccesary stuff from the match row
		$match_id = $match_data['match_id'];
		$half_id = $match_data['half1_id'];
		$map1_id = $match_data['map1_id'];
		$map2_id = $match_data['map2_id'];
	
		// Get team_id's from half_id
		$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
		$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		$half_data = mysql_fetch_array($half_query);
		
		$team1_id = $half_data['team1_id'];
		$team2_id = $half_data['team2_id'];
		
		// Get Team names from team_id's
		// Get team1_id name
		$team1_name = get_team_name($team1_id, $link);
		$team1_name = htmlspecialchars($team1_name);
		
		
		// Get team2_id name
		$team2_name = get_team_name($team2_id, $link);
		$team2_name = htmlspecialchars($team2_name);
		
		
		// Get map name from map1_id
		$map1_name = get_map_name($map1_id, $link);
		
		if( $map2_id != -1 )
		{
			$map2_name = get_map_name($map2_id, $link);
		}
		else
		{
			$map2_name = "";
		}
		

		// Get team scores

		$team1_score = 0;
		$team2_score = 0;

		for($i = 1; $i < 9; $i++)
		{	
			// Pull the neccesary stuff from the match row
			$half_id = $match_data["half" . $i . "_id"];
			
			if( $half_id != -1 )
			{
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);
				
				if( $i % 2 == 0 )
				{
					$team2_score += $half_data['team1_score'];
					$team1_score += $half_data['team2_score'];
				}
				else
				{
					$team1_score += $half_data['team1_score'];
					$team2_score += $half_data['team2_score'];
				}
			}
		}		
		
		// Change shade from 2 to 3 -or- 3 to 2
		$shade += $shade_changer;
		$shade_changer = -$shade_changer;
?>		
			<tr class="table-shade<?=$shade?>">
				<td align="center"><a href="index.php?match=<?=$match_id?>"><?=$j?></a></td>
				<td align="left"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a></td>
				<td align="left"><?=$team1_score?></td>
				<td align="left"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a></td>
				<td align="left"><?=$team2_score?></td>
				<td align="left"><a href="map.php?map=<?=$map1_id?>"><?=$map1_name?></a></td>
				<td align="left"><a href="map.php?map=<?=$map2_id?>"><?=$map2_name?></a></td>
			</tr>
<?php

	}
	
?>
		</table>
		<br />
		<br />

<?php

}

?>

		<div class="clearer"></div>
	
		<div class="bottom">
			
			<span class="left">&copy; 2007 Infra. Valid <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> &amp; <a href="http://validator.w3.org/check?uri=referer">XHTML</a>.</span>
			<span class="right">Template design by Infra</span>
	
			<div class="clearer"></div>
	
		</div>

	</div>

</div>

</body>

</html>