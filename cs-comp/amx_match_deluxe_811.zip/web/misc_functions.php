<?php
/*************************************************************
*
*	Misc Functions file for AMXMD Template
*
*************************************************************/

include_once("config.php");

function get_team_name( $team_id, $link )
{
	// Get team name from team_id
	$sql = "SELECT * FROM `amx_match_team` WHERE `team_id`=" . $team_id;
	$team_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	$team_data = mysql_fetch_array($team_query);	
	
	$team_name = $team_data['team_name'];
				
	return $team_name;	
}

function get_map_name( $map_id, $link )
{
	// Get map name from map_id
	$sql = "SELECT * FROM `amx_match_map` WHERE `map_id`=" . $map_id;
	$map_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	$map_data = mysql_fetch_array($map_query);
	
	$map_name = $map_data['map_name'];
	
	return $map_name;
}

function get_player_steamid( $player_id, $link )
{
	// Get player steamid from player_id
	$sql = "SELECT * FROM `amx_match_player` WHERE `player_id`=" . $player_id;
	$player_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	$player_data = mysql_fetch_array($player_query);	
	
	$player_steamid = $player_data['player_steamid'];

	return $player_steamid;		
}

function get_player_name( $player_id, $link )
{
	// Get player name from player_id
	$sql = "SELECT * FROM `amx_match_player_name` WHERE `player_id`=" . $player_id . " LIMIT 1";
	$player_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	$player_data = mysql_fetch_array($player_query);	
	
	$player_name = $player_data['player_name'];

	return $player_name;		
}
	

?>