<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<?php

	include_once("config.php");
	include_once("misc_functions.php");
	include_once("mysql_connect.php");
	
?>


<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
	<meta name="description" content="description"/>
	<meta name="keywords" content="keywords"/> 
	<meta name="author" content="Infra"/> 
	<link rel="stylesheet" type="text/css" href="default.css" media="screen"/>
<?php

if ( isset($_GET["player"]) && $_GET["player"] > 0 )
{

	$sql = "SELECT * FROM `amx_match_player` WHERE `player_id`=" . $_GET["player"];
	$player_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($player_data = mysql_fetch_array($player_query, MYSQL_BOTH))
	{
		$player_name = get_player_name( $_GET["player"], $link );
		$player_name = htmlspecialchars($player_name);
?>

	<title><?=$server_name?> - Player <?=$player_name?></title>

<?php

	}
	else
	{	
	
?>

	<title><?=$server_name?> - Player #<?=$_GET["player"]?></title>
	
<?php

	}

}
else
{
	
	
?>

	<title><?=$server_name?> - Players</title>
	
<?php

}

?>

</head>

<!-- default margin = default layout -->
<body style="margin: 0 12%;">

<div class="container">

	<div class="header">
		<a href="index.php"><span><?=$server_name?></span></a>
	</div>
	
	<div class="nav">
		<a href="index.php">Matches</a>
		<a href="player.php">Players</a>
		<a href="team.php">Teams</a>
		<a href="map.php">Maps</a>
		<div class="clearer"></div>
	</div>

	<div class="stripes"></div>

	<div class="main">


<?php

if ( isset($_GET["player"]) && $_GET["player"] > 0 )
{
		
	$sql = "SELECT * FROM `amx_match_player` WHERE `player_id`=" . $_GET["player"];
	$player_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($player_data = mysql_fetch_array($player_query, MYSQL_BOTH))
	{
		$player_id = $player_data['player_id'];
		
		$player_name = get_player_name( $player_id, $link );
		$player_name = htmlspecialchars ( $player_name );
	
?>

		<div class="listing">
			Player Listing - Player <?=$player_name?>
		</div>

<?php


		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `player_id`=" . $player_id;
		$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		$matches_won = 0;
		$matches_lost = 0;
		
		while( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
		{
			$half_id = $player_stats_data['half_id'];
			$team_id = $player_stats_data['team_id'];
	
			// Get matches that the player played in
			$sql = "SELECT * FROM `amx_match_main` WHERE `half1_id`=" . $half_id;
			$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
			$team1_score = 0;
			$team2_score = 0;
		
			if ($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
			{
				for($i = 1; $i < 9; $i++)
				{	
					// Pull the neccesary stuff from the match row
					$half_id = $match_data["half" . $i . "_id"];
					
					if( $half_id != -1 )
					{
						// Get team_id's from half_id
						$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
						$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
						$half_data = mysql_fetch_array($half_query);
						
						if( $i % 2 == 0 )
						{
							$team2_score += $half_data['team1_score'];
							$team1_score += $half_data['team2_score'];
						}
						else
						{
							$team1_score += $half_data['team1_score'];
							$team2_score += $half_data['team2_score'];
						}
					}
				}
	
				// Pull the neccesary stuff from the half row
				$half_id = $match_data["half1_id"];
				
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);			
				
				$team2_id = $half_data['team2_id'];
				
				if ( $team2_id == $team_id )
				{
					$temp = $team1_score;
					$team1_score = $team2_score;
					$team2_score = $temp;
				}
				
				
				if( $team1_score > $team2_score )
				{
					$matches_won++;
				}
				else
				{
					$matches_lost++;
				}
			}
		}
		
?>

		<br />
		<div class="content-title">Win/Loss:</div>
		<table class="content" width="10%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td class="table-shade4" style="padding-left: 3px; width: 40%;" align="center">Won</td>
				<td class="table-shade2" style="width: 60%;border-bottom: 1px solid black;" align="center"><?=$matches_won?></td>
			</tr>
			
			<tr>
				<td class="table-shade5" style="padding-left: 3px; width: 40%;" align="center">Lost</td>
				<td class="table-shade3" style="width: 60%;" align="center"><?=$matches_lost?></td>
			</tr>
		</table>
		
		<br />
		<br />

<?php

		// Get player steamid
		$player_steamid = get_player_steamid( $player_id, $link);
		$player_steamid = htmlspecialchars( $player_steamid );
		
?>

		<div class="content-title">SteamID: <span style="font-weight: bold;"><?=$player_steamid?></span></div>

		<br />
		<br />

		<table style="margin-left: 2%" width="97%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td valign="top" style="width: 30%;">
					<div class="content-title2">Names:</div>
					<table class="content2" width="96%" cellpadding="0" cellspacing="0" border="0">
						<tr class="table-shade1">
							<td align="center" style="width: 10%;">#</td>
							<td align="center" style="width: 90%;">Name</td>
						</tr>
<?php

		$i = 0;
		
		$shade_changer = -1;
		$shade = 3;
		
		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_name` WHERE `player_id`=" . $player_id;
		$player_name_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());

		while( $player_name_data = mysql_fetch_array($player_name_query, MYSQL_BOTH))
		{
			$player_name = $player_name_data['player_name'];
			$player_name = htmlspecialchars( $player_name );

			$i++;
	
			// Change shade from 2 to 3 -or- 3 to 2
			$shade += $shade_changer;
			$shade_changer = -$shade_changer;	
?>
						
						<tr class="table-shade2">
							<td align="center"><?=$i?></td>
							<td align="center"><?=$player_name?></td>
						</tr>
						
<?php

		}
		
?>
					</table>
				</td>				
				
				<td valign="top" style="width: 15%;">
					<div class="content-title">Teams:</div>
					<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
						<tr class="table-shade1">
							<td align="center" style="width: 15%;">#</td>
							<td align="center" style="width: 85%;">Team</td>
						</tr>

<?php
		$i = 0;

		$shade_changer = -1;
		$shade = 3;

		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `player_id`=" . $player_id . " GROUP BY `team_id`";
		$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		while( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
		{
			$i++;
			
			$team_id = $player_stats_data['team_id'];
			
			//Get team name
			$team_name = get_team_name( $team_id, $link );
			$team_name = htmlspecialchars($team_name);
			
			// Change shade from 2 to 3 -or- 3 to 2
			$shade += $shade_changer;
			$shade_changer = -$shade_changer;
?>
			
			<tr class="table-shade<?=$shade?>">
				<td align="center"><?=$i?></td>
				<td align="center"><a href="team.php?team=<?=$team_id?>"><?=$team_name?></a></td>
			</tr>
<?php

		}			

?>
			
					</table>
				</td>
				
				<td style="width: 55%;">&nbsp;</td>
				
			</tr>
		</table>
					
					

		<br />
		<br />
		
		<div class="content-title">Matches:</div>
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 2%;">#</td>
				<td align="left" style="width: 25%;">Team</td>
				<td align="left" style="width: 25%;">Against</td>
				<td align="left" style="width: 14%;">First Map</td>
				<td align="left" style="width: 14%;">Second Map</td>
			</tr>

<?php

		$i = 0;

		$shade_changer = -1;
		$shade = 3;

		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `player_id`=" . $player_id;
		$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		while( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
		{
			$half_id = $player_stats_data['half_id'];
			$team_id = $player_stats_data['team_id'];


			// Get matches that the team played in
			$sql = "SELECT * FROM `amx_match_main` WHERE `half1_id`=" . $half_id;
			$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
			if ($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
			{
				$i++;				
				
				$match_id = $match_data['match_id'];
				$map1_id = $match_data['map1_id'];
				$map2_id = $match_data['map2_id'];
				
				
				// Get halves that the team played in
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);
				
				$team1_id = $half_data['team1_id'];
				$team2_id = $half_data['team2_id'];			
				
				
				if( $team1_id != $team_id )
				{
					// Get Team names from team_id's
					// Get team1_id name
					$match_against = get_team_name($team1_id, $link);
					$match_against_id = $team1_id;
					
					// Get team2_id name
					$team_name = get_team_name($team2_id, $link);
				}
				else
				{
					// Get team1_id name
					$team_name = get_team_name($team1_id, $link);					
					
					// Get team2_id name
					$match_against = get_team_name($team2_id, $link);
					$match_against_id = $team2_id;
				}
				
				$match_against = htmlspecialchars($match_against);
				$team_name = htmlspecialchars($team_name);
				

				// Get map name from map_id
				$map1_name = get_map_name( $map1_id, $link );
				
				if( $map2_id != -1 )
				{
					// Get map name from map_id2
					$map2_name = get_map_name( $map2_id, $link );
				}
				else
				{
					$map2_name = "";
				}
						
				// Change shade from 2 to 3 -or- 3 to 2
				$shade += $shade_changer;
				$shade_changer = -$shade_changer;				
		
?>
			
			<tr class="table-shade<?=$shade?>">
				<td align="center"><a href="index.php?match=<?=$match_id?>"><?=$i?></a></td>
				<td align="left"><a href="team.php?team=<?=$team_id?>"><?=$team_name?></a></td>
				<td align="left"><a href="team.php?team=<?=$match_against_id?>"><?=$match_against?></a></td>
				<td align="left"><a href="map.php?map=<?=$map1_id?>"><?=$map1_name?></a></td>
				<td align="left"><a href="map.php?map=<?=$map2_id?>"><?=$map2_name?></a></td>
			</tr>
<?php

			}
		}			

?>

		</table>
		
		<br />
		<br />

		<div class="content-title">Maps:</div>
		<table class="content" width="35%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 5%;">#</td>
				<td align="left" style="width: 65%;">Map Name</td>
				<td align="center" style="width: 15%;">Matches Won</td>
				<td align="center" style="width: 15%;">Matches Lost</td>
			</tr>	

<?php

		// Initialize win/loss arrays
		$sql = "SELECT * FROM `amx_match_map` ORDER BY `map_id` ASC;";
		$map_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		while( $map_data = mysql_fetch_array($map_query, MYSQL_BOTH))
		{
			$map_id = $map_data['map_id'];
			
			$map_matches_won[$map_id] = 0;
			$map_matches_lost[$map_id] = 0;
		}

		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `player_id`=" . $player_id;
		$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		while( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
		{
			$half_id = $player_stats_data['half_id'];
			$team_id = $player_stats_data['team_id'];
	
			// Get matches that the player played in
			$sql = "SELECT * FROM `amx_match_main` WHERE `half1_id`=" . $half_id;
			$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
			$team1_score = 0;
			$team2_score = 0;
		
			if ($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
			{
				$map1_id = $match_data['map1_id'];
				$map2_id = $match_data['map2_id'];
				
				$map_name[$map1_id] = get_map_name( $map1_id, $link );
				
				if( $map2_id != -1 )
				{				
					$map_name[$map2_id] = get_map_name( $map2_id, $link );
				}
				
				
				for($i = 1; $i < 9; $i++)
				{	
					// Pull the neccesary stuff from the match row
					$half_id = $match_data["half" . $i . "_id"];
					
					if( $half_id != -1 )
					{
						// Get team_id's from half_id
						$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
						$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
						$half_data = mysql_fetch_array($half_query);
						
						if( $i % 2 == 0 )
						{
							$team2_score += $half_data['team1_score'];
							$team1_score += $half_data['team2_score'];
						}
						else
						{
							$team1_score += $half_data['team1_score'];
							$team2_score += $half_data['team2_score'];
						}
					}
				}
	
				// Pull the neccesary stuff from the half row
				$half_id = $match_data["half1_id"];
				
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);			
				
				$team2_id = $half_data['team2_id'];
				
				if ( $team2_id == $team_id )
				{
					$temp = $team1_score;
					$team1_score = $team2_score;
					$team2_score = $temp;
				}
				
				
				if( $team1_score > $team2_score )
				{
					$map_matches_won[$map1_id]++;
					
					if( $map2_id != -1 )
					{
						$map_matches_won[$map2_id]++;
					}
				}
				else
				{
					$map_matches_lost[$map1_id]++;
					
					if( $map2_id != -1 )
					{
						$map_matches_lost[$map2_id]++;
					}
				}
			}
		}
		
		$j = 0;
		
		$shade_changer = -1;
		$shade = 3;	
		
		foreach ($map_name as $i => $value)
		{
			$j++;

			// Change shade from 2 to 3 -or- 3 to 2
			$shade += $shade_changer;
			$shade_changer = -$shade_changer;
		
?>
			<tr class="table-shade<?=$shade?>">
				<td align="center" style="width: 5%;"><?=$j?></td>
				<td align="left" style="width: 65%;"><a href="map.php?map=<?=$i?>"><?=$value?></a></td>
				<td align="center" style="width: 15%;"><?=$map_matches_won[$i]?></td>
				<td align="center" style="width: 15%;"><?=$map_matches_lost[$i]?></td>
			</tr>		
<?php

		}
		
?>

		</table>
		<br />
		<br />
<?php
		
	}
	else
	{
		
?>
		<br />
		<br />
		<div class="content-title">Error: Invalid player number: <?=$_GET["player"]?></div>
		<br />
		<br />
		
<?php
	}
	
}	
else
{
	
?>

		<div class="listing">
			Player Listing
		</div>	

		<br />
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 5%;">#</td>
				<td align="left" style="width: 25%;">SteamID</td>
				<td align="left" style="width: 30%;">Name</td>
				<td align="center" style="width: 20%;">Matches Won</td>
				<td align="center" style="width: 20%;">Matches Lost</td>
			</tr>

<?php

	$j = 0;

	$shade_changer = -1;
	$shade = 3;

	// Get halves that the player played in
	$sql = "SELECT * FROM `amx_match_player` ORDER BY `player_id` ASC";
	$player_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	while( $player_data = mysql_fetch_array($player_query, MYSQL_BOTH))
	{
		$j++;		
		
		$player_id = $player_data['player_id'];
		
		// Get player's steamid
		$player_steamid = $player_data['player_steamid'];
		$player_steamid = htmlspecialchars($player_steamid);
		
		$player_name = get_player_name($player_id, $link);
		$player_name = htmlspecialchars($player_name);
		
		$matches_won = 0;
		$matches_lost = 0;
		
		// Get halves that the player played in
		$sql = "SELECT * FROM `amx_match_player_statistics` WHERE `player_id`=" . $player_id;
		$player_stats_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		
		while( $player_stats_data = mysql_fetch_array($player_stats_query, MYSQL_BOTH))
		{
			$half_id = $player_stats_data['half_id'];
			$team_id = $player_stats_data['team_id'];
	
			// Get matches that the player played in
			$sql = "SELECT * FROM `amx_match_main` WHERE `half1_id`=" . $half_id;
			$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
			$team1_score = 0;
			$team2_score = 0;
		
			if ($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
			{
				for($i = 1; $i < 9; $i++)
				{	
					// Pull the neccesary stuff from the match row
					$half_id = $match_data["half" . $i . "_id"];
					
					if( $half_id != -1 )
					{
						// Get team_id's from half_id
						$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
						$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
						$half_data = mysql_fetch_array($half_query);
						
						if( $i % 2 == 0 )
						{
							$team2_score += $half_data['team1_score'];
							$team1_score += $half_data['team2_score'];
						}
						else
						{
							$team1_score += $half_data['team1_score'];
							$team2_score += $half_data['team2_score'];
						}
					}
				}
	
				// Pull the neccesary stuff from the half row
				$half_id = $match_data["half1_id"];
				
				// Get team_id's from half_id
				$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
				$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
				$half_data = mysql_fetch_array($half_query);			
				
				$team2_id = $half_data['team2_id'];
				
				if ( $team2_id == $team_id )
				{
					$temp = $team1_score;
					$team1_score = $team2_score;
					$team2_score = $temp;
				}
				
				
				if( $team1_score > $team2_score )
				{
					$matches_won++;
				}
				else
				{
					$matches_lost++;
				}
			}
		}
	
		// Change shade from 2 to 3 -or- 3 to 2
		$shade += $shade_changer;
		$shade_changer = -$shade_changer;
?>
	
			<tr class="table-shade<?=$shade?>">
				<td align="center"><?=$j?></td>
				<td align="left"><a href="player.php?player=<?=$player_id?>"><?=$player_steamid?></a></td>
				<td align="left"><?=$player_name?></td>
				<td align="center"><?=$matches_won?></td>
				<td align="center"><?=$matches_lost?></td>
			</tr>
<?php

	}
	
?>
		</table>
		<br />
		<br />

<?php

}

?>

		<div class="clearer"></div>
	
		<div class="bottom">
			
			<span class="left">&copy; 2007 Infra. Valid <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> &amp; <a href="http://validator.w3.org/check?uri=referer">XHTML</a>.</span>
			<span class="right">Template design by Infra</span>
	
			<div class="clearer"></div>
	
		</div>

	</div>

</div>

</body>

</html>