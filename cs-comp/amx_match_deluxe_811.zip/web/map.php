<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<?php

	include_once("config.php");
	include_once("misc_functions.php");
	include_once("mysql_connect.php");
	
?>


<html>

<head>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
	<meta name="description" content="description"/>
	<meta name="keywords" content="keywords"/> 
	<meta name="author" content="Infra"/> 
	<link rel="stylesheet" type="text/css" href="default.css" media="screen"/>
<?php

if ( isset($_GET["map"]) && $_GET["map"] > 0 )
{

	$sql = "SELECT * FROM `amx_match_map` WHERE `map_id`=" . $_GET["map"];
	$map_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($map_data = mysql_fetch_array($map_query, MYSQL_BOTH))
	{
		$map_name = $map_data['map_name'];
		$map_name = htmlspecialchars($map_name);
?>

	<title><?=$server_name?> - Map <?=$map_name?></title>

<?php

	}
	else
	{	
	
?>

	<title><?=$server_name?> - Map #<?=$_GET["map"]?></title>
	
<?php

	}

}
else
{
	
	
?>

	<title><?=$server_name?> - Maps</title>
	
<?php

}

?>

</head>

<!-- default margin = default layout -->
<body style="margin: 0 12%;">

<div class="container">

	<div class="header">
		<a href="index.php"><span><?=$server_name?></span></a>
	</div>
	
	<div class="nav">
		<a href="index.php">Matches</a>
		<a href="player.php">Players</a>
		<a href="team.php">Teams</a>
		<a href="map.php">Maps</a>
		<div class="clearer"></div>
	</div>

	<div class="stripes"></div>

	<div class="main">


<?php

if ( isset($_GET["map"]) && $_GET["map"] > 0 )
{
		
	$sql = "SELECT * FROM `amx_match_map` WHERE `map_id`=" . $_GET["map"];
	$map_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	if($map_data = mysql_fetch_array($map_query, MYSQL_BOTH))
	{
		$map_name = $map_data['map_name'];
		
		// Get number of matches from map_id
		$sql = "SELECT * FROM `amx_match_main` WHERE `map1_id`=" . $_GET["map"] . " OR `map2_id`=" . $_GET["map"];
		$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		$num_matches = mysql_num_rows($match_query);
?>
		
		<div class="listing">
			Map Listing - Map <?=$map_name?>
		</div>
		
		<br />
		<div class="content-title">Number of Matches:</div>
		<table class="content" width="10%" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td class="table-shade2" style="width: 60%;" align="center"><?=$num_matches?></td>
			</tr>
		</table>
		
		<br />
		<br />
		<div class="content-title">Matches:</div>
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 5%;">#</td>
				<td align="left" style="width: 25%;">Team 1</td>
				<td align="left" style="width: 25%;">Team 2</td>
				<td align="left" style="width: 25%;">First Map</td>
				<td align="left" style="width: 20%;">Second Map</td>
			</tr>
		
<?php

		$shade_changer = -1;
		$shade = 3;
		
		$i = 0;

		while($match_data = mysql_fetch_array($match_query, MYSQL_BOTH))
		{
			$i++;
			
			// Pull the neccesary stuff from the match row
			$match_id = $match_data['match_id'];
			$half_id = $match_data['half1_id'];
			$map1_id = $match_data['map1_id'];
			$map2_id = $match_data['map2_id'];
		
			// Get team_id's from half_id
			$sql = "SELECT * FROM `amx_match_half` WHERE `half_id`=" . $half_id;
			$half_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
			$half_data = mysql_fetch_array($half_query);
			
			$team1_id = $half_data['team1_id'];
			$team2_id = $half_data['team2_id'];
			
			// Get Team names from team_id's
			// Get team1_id name
			$team1_name = get_team_name($team1_id, $link);
			$team1_name = htmlspecialchars($team1_name);
			
			
			// Get team2_id name
			$team2_name = get_team_name($team2_id, $link);
			$team2_name = htmlspecialchars($team2_name);
			
			
			// Get map name from map1_id
			$map1_name = get_map_name($map1_id, $link);
			
			if( $map2_id != -1 )
			{
				$map2_name = get_map_name($map2_id, $link);
			}
			else
			{
				$map2_name = "";
			}
					
			if( $map1_id != $_GET["map"])
			{
				$map1_href = "<a href=\"map.php?map=" . $map1_id . "\">" . $map1_name . "</a>";
				$map2_href = $map2_name;
			}
			else
			{
				$map1_href = $map1_name;				
				$map2_href = "<a href=\"map.php?map=" . $map2_id . "\">" . $map2_name . "</a>";
			}
			
			// Change shade from 2 to 3 -or- 3 to 2
			$shade += $shade_changer;
			$shade_changer = -$shade_changer;
?>		
			<tr class="table-shade<?=$shade?>">
				<td align="center"><a href="index.php?match=<?=$match_id?>"><?=$i?></a></td>
				<td align="left"><a href="team.php?team=<?=$team1_id?>"><?=$team1_name?></a></td>
				<td align="left"><a href="team.php?team=<?=$team2_id?>"><?=$team2_name?></a></td>
				<td align="left"><?=$map1_href?></td>
				<td align="left"><?=$map2_href?></td>
			</tr>
<?php

		}
	
?>
		</table>
		<br />
		<br />

<?php

	}
	else
	{
		
?>
		<br />
		<br />
		<div class="content-title">Error: Invalid map number: <?=$_GET["map"]?></div>
		<br />
		<br />
		
<?php
	}
	
}	
else
{
	
?>

		<div class="listing">
			Map Listing
		</div>	

		<br />
		<table class="content" width="96%" cellpadding="0" cellspacing="0" border="0">
			<tr class="table-shade1">
				<td align="center" style="width: 5%;">#</td>
				<td align="left" style="width: 70%;">Map Name</td>
				<td align="center" style="width: 25%;">Number of Matches</td>
			</tr>

<?php

	$shade_changer = -1;
	$shade = 3;
	
	$i = 0;
	
	$sql = "SELECT * FROM `amx_match_map` ORDER BY `map_id` ASC;";
	$map_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
	
	while($map_data = mysql_fetch_array($map_query, MYSQL_BOTH))
	{
		$i++;
		
		// Pull the neccesary stuff from the team row
		$map_id = $map_data['map_id'];
		
		
		$map_name = $map_data['map_name'];
		$map_name = htmlspecialchars($map_name);
		
	
		// Get number of matches from map_id
		$sql = "SELECT * FROM `amx_match_main` WHERE `map1_id`=" . $map_id . " OR `map2_id`=" . $map_id;
		$match_query = mysql_query($sql, $link) or die("Cannot query the database: " . mysql_error());
		$num_matches = mysql_num_rows($match_query);

	
		// Change shade from 2 to 3 -or- 3 to 2
		$shade += $shade_changer;
		$shade_changer = -$shade_changer;
?>
	
			<tr class="table-shade<?=$shade?>">
				<td align="center"><?=$i?></td>
				<td align="left"><a href="map.php?map=<?=$map_id?>"><?=$map_name?></a></td>
				<td align="center"><?=$num_matches?></td>
			</tr>
<?php

	}
	
?>
		</table>
		<br />
		<br />

<?php

}

?>

		<div class="clearer"></div>
	
		<div class="bottom">
			
			<span class="left">&copy; 2007 Infra. Valid <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> &amp; <a href="http://validator.w3.org/check?uri=referer">XHTML</a>.</span>
			<span class="right">Template design by Infra</span>
	
			<div class="clearer"></div>
	
		</div>

	</div>

</div>

</body>

</html>