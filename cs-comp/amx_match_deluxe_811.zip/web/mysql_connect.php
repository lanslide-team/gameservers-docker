<?php
/*************************************************************
*
*	Database connection file for AMXMD Template
*
*************************************************************/

include("config.php");

$link = mysql_connect($mysql_host,$mysql_username,$mysql_password) or die("Could not connect: " . mysql_error());
$selected_db = mysql_select_db($mysql_database, $link) or die( "Unable to select database: " . mysql_error() );

?>
